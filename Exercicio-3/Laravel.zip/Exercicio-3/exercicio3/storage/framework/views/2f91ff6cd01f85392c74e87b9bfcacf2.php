<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Jogo da Forca 2.0</title>
</head>
<body>
    <h1>Hello Word!</h1>
</body>
</html><?php /**PATH C:\Users\Loit Corp 01\Documents\Treinamento\Estagio\Exercicio-3\exercicio3\resources\views/welcome.blade.php ENDPATH**/ ?>